
# pptos

<!-- badges: start -->
<!-- badges: end -->

The goal of pptos is to ...

## Installation

You can install the released version of pptos from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("pptos")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(pptos)
## basic example code
```

